﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace drivers
{
    public partial class Form1 : Form
    {
        private Form2 form2;
        public Form1()
        {
            InitializeComponent();
            form2 = new Form2(this) { Visible = false };
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            form2.Visible = true;
        }
        private Form3 form3;
        private void button2_Click(object sender, EventArgs e)
        {
            form3 = new Form3(this) { Visible = false };
            this.Visible = false;
            form3.Visible = true;
        }
        private Form4 form4;
        private void button3_Click(object sender, EventArgs e)
        {
            form4 = new Form4(this) { Visible = false };
            this.Visible = false;
            form4.Visible = true;
        }
        private Form5 form5;
        private void button4_Click(object sender, EventArgs e)
        {
            form5 = new Form5(this) { Visible = false };
            this.Visible = false;
            form5.Visible = true;
        }
    }
}

