﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using drivers.ModelEF;

namespace drivers
{
    public partial class Form2Edit : Form
    {
        public Model1 db { get; set; }
        public Form2Edit()
        {
            InitializeComponent();
        }
        private void Form2Edit_Load(object sender, EventArgs e)
        {
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == " " || textBox2.Text == " ")
            {
                MessageBox.Show("Нужно ввести все требуемые данные!");
                return;
            }
            int id;
            bool b = int.TryParse(textBox1.Text, out id);
            if (b == false)
            {
                MessageBox.Show("Неверный формат ID - " + textBox1.Text);
                return;
            }
            Drivers drv = new Drivers();
            drv.DriverID = id;
            drv.Name = textBox2.Text;
            drv.MiddleName = textBox3.Text;
            drv.PassportSerial = textBox4.Text;
            drv.PassportNumber = textBox5.Text;
            drv.Postcode = textBox6.Text;
            drv.Address = textBox7.Text;
            drv.Company = textBox8.Text;
            drv.JobName = textBox9.Text;
            drv.Phone = textBox10.Text;
            drv.Email = textBox11.Text;
            db.Drivers.Add(drv);
            try
            {
                db.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
        }
    }
}

