﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using drivers.ModelEF;

namespace drivers
{
    public partial class Form4Edit : Form
    {
        public Model1 db { get; set; }
        public Form4Edit()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == " " || textBox2.Text == " ")
            {
                MessageBox.Show("Нужно ввести все требуемые данные!");
                return;
            }
            int id;
            bool b = int.TryParse(textBox1.Text, out id);
            if (b == false)
            {
                MessageBox.Show("Неверный формат ID - " + textBox1.Text);
                return;
            }
            Manufacturer mnf = new Manufacturer();
            mnf.ManufacturerID = id;
            mnf.VIN = textBox2.Text;
            mnf.Manufacturer1 = textBox3.Text;
            mnf.Model = textBox4.Text;
            mnf.Year = textBox5.Text;
            mnf.Weight = textBox6.Text;
            mnf.Color = textBox7.Text;
            mnf.EngineType = textBox8.Text;
            mnf.TypeOfDriver = textBox9.Text;
            db.Manufacturer.Add(mnf);
            try
            {
                db.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }
    }
}
