﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using drivers.ModelEF;

namespace drivers
{
    public partial class Form5 : Form
    {
        Model1 db = new Model1();
        private Form1 _form1;
        public Form5(Form1 form1)
        {
            _form1 = form1;
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            _form1.Visible = true;
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            categoryBindingSource.DataSource = db.Category.ToList();
        }

    }
}
