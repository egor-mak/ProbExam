namespace drivers.ModelEF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Licences
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int LicenceID { get; set; }

        [Required]
        [StringLength(50)]
        public string LicenceDate { get; set; }

        [Required]
        [StringLength(50)]
        public string ExpireDate { get; set; }

        [Required]
        [StringLength(10)]
        public string Categories { get; set; }

        [Required]
        [StringLength(10)]
        public string LicenceSeries { get; set; }

        [Required]
        [StringLength(10)]
        public string LicenceNumber { get; set; }

        [Required]
        [StringLength(50)]
        public string Status { get; set; }
    }
}
