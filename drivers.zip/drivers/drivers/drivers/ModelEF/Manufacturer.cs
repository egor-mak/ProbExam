namespace drivers.ModelEF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Manufacturer")]
    public partial class Manufacturer
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ManufacturerID { get; set; }

        [Required]
        [StringLength(50)]
        public string VIN { get; set; }

        [Column("Manufacturer")]
        [Required]
        [StringLength(20)]
        public string Manufacturer1 { get; set; }

        [Required]
        [StringLength(50)]
        public string Model { get; set; }

        [Required]
        [StringLength(4)]
        public string Year { get; set; }

        [Required]
        [StringLength(6)]
        public string Weight { get; set; }

        [Required]
        [StringLength(5)]
        public string Color { get; set; }

        [Required]
        [StringLength(10)]
        public string EngineType { get; set; }

        [Required]
        [StringLength(50)]
        public string TypeOfDriver { get; set; }
    }
}
