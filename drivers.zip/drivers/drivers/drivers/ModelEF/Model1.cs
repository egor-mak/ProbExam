using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace drivers.ModelEF
{
    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<Drivers> Drivers { get; set; }
        public virtual DbSet<Licences> Licences { get; set; }
        public virtual DbSet<Manufacturer> Manufacturer { get; set; }
        public virtual DbSet<Category> Category { get; set; }
        public virtual DbSet<LogPass> LogPass { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Drivers>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<Licences>()
                .Property(e => e.Categories)
                .IsFixedLength();

            modelBuilder.Entity<Licences>()
                .Property(e => e.LicenceNumber)
                .IsFixedLength();

            modelBuilder.Entity<Manufacturer>()
                .Property(e => e.VIN)
                .IsFixedLength();

            modelBuilder.Entity<Manufacturer>()
                .Property(e => e.Manufacturer1)
                .IsFixedLength();

            modelBuilder.Entity<Manufacturer>()
                .Property(e => e.Model)
                .IsFixedLength();

            modelBuilder.Entity<Manufacturer>()
                .Property(e => e.Year)
                .IsFixedLength();

            modelBuilder.Entity<Manufacturer>()
                .Property(e => e.Weight)
                .IsFixedLength();

            modelBuilder.Entity<Manufacturer>()
                .Property(e => e.Color)
                .IsFixedLength();

            modelBuilder.Entity<Manufacturer>()
                .Property(e => e.EngineType)
                .IsFixedLength();

            modelBuilder.Entity<Manufacturer>()
                .Property(e => e.TypeOfDriver)
                .IsFixedLength();

            modelBuilder.Entity<Category>()
                .Property(e => e.CategoryTC)
                .IsFixedLength();

            modelBuilder.Entity<Category>()
                .Property(e => e.TechCategoryTC)
                .IsFixedLength();

            modelBuilder.Entity<LogPass>()
                .Property(e => e.Login)
                .IsFixedLength();

            modelBuilder.Entity<LogPass>()
                .Property(e => e.Password)
                .IsFixedLength();
        }
    }
}
